(function () {

  let btnStatus = "UNDEFINED"; // "UNDEFINED" "CONNECTING" "OPEN" "CLOSING" "CLOSED"

  const btnControl = document.getElementById("btn_control");

  const recorder = new RecorderManager("../../dist");
  recorder.onStart = () => {
    changeBtnStatus("OPEN");
  }
  let iatWS;
  let resultText = "";
  let resultTextTemp = "";
  let countdownInterval;
var timer = null // 全局定时器

  /**
   * 获取websocket url
   * 该接口需要后端提供，这里为了方便前端处理
   */
  function getWebSocketUrl() {
    // // 请求地址根据语种不同变化
    // var url = "wss://rtasr.xfyun.cn/v1/ws";
    // var appId = '5f3b5084';
    // var secretKey = '6c6fd02030e9b8b95dbb2f6370c7d5dd';
    // var ts = Math.floor(new Date().getTime() / 1000);
    // var signa = hex_md5(appId + ts);
    // var signatureSha = CryptoJSNew.HmacSHA1(signa, secretKey);
    // var signature = CryptoJS.enc.Base64.stringify(signatureSha);
    // signature = encodeURIComponent(signature);
    // return `${url}?appid=${appId}&ts=${ts}&signa=${signature}`;
    return 'wss://ubms.gtjazg.com/ast'
  }

  function changeBtnStatus(status) {
    btnStatus = status;
    if (status === "CONNECTING") {
      btnControl.innerText = "建立连接中";
      document.getElementById("result").innerText = "";
      resultText = "";
      resultTextTemp = "";
    } else if (status === "OPEN") {
      btnControl.innerText = "录音中";
    } else if (status === "CLOSING") {
      const edMsg = {
        action: 'end',
        id: '123',
        param: ''
    }
    iatWS.send(JSON.stringify(edMsg))  
      btnControl.innerText = "关闭连接中";
    } else if (status === "CLOSED") {
      btnControl.innerText = "开始录音";
    }
  }

  function renderResult(resultData) {
    let data = JSON.parse(resultData)
    if (data.action != 'result') {
      return
    }
    handleResultAndSave(data)
    // let jsonData = JSON.parse(resultData);
    // if (jsonData.action == "started") {
    //   // 握手成功
    //   console.log("握手成功");
    // } else if (jsonData.action == "result") {
    //   const data = JSON.parse(jsonData.data)
    //   console.log(data)
    //   // 转写结果
    //   let resultTextTemp = ""
    //   data.cn.st.rt.forEach((j) => {
    //     j.ws.forEach((k) => {
    //       k.cw.forEach((l) => {
    //         resultTextTemp += l.w;
    //       });
    //     });
    //   });
    //   if (data.cn.st.type == 0) {
    //     // 【最终】识别结果：
    //     resultText += resultTextTemp;
    //     resultTextTemp = ""
    //   }
    //   document.getElementById("result").innerText = resultText + resultTextTemp
    // } else if (jsonData.action == "error") {
    //   // 连接发生错误
    //   console.log("出错了:", jsonData);
    // }
  }
  function handleResultAndSave(data){
    const result = JSON.parse(data.content);
    let oldWordStr = '' //中间结果
    let endWordStr = '' //最终结果
    const ws = result.ws;
    const msgtype = result.msgtype // progressive 中间结果 sentence 最终结果  
    let renderWordStr = ''
    if (msgtype == 'progressive') {
      for (let j = 0; j < ws.length; j++) {
        const wsObj = ws[j];
        const cw = wsObj.cw;
        for (let k = 0; k < cw.length; k++) {
          const cwObj = cw[k];
          const wordObj = cwObj.w;
          const wpObj = cwObj.wp;
          oldWordStr += wordObj.toString();
          renderWordStr += wordObj.toString();
          if (wpObj.toString() === "g") {
            oldWordStr += "\r\n";
            renderWordStr += "\r\n";
          }
        }
      }
      oldWordStr = oldWordStr ?  oldWordStr : ''
      renderWordStr = renderWordStr ? renderWordStr : ''
      renderIntermediateResult(oldWordStr, renderWordStr)
    } else {
      let finalWordStr = ''
      for (let j = 0; j < ws.length; j++) {
        const wsObj = ws[j];
        const cw = wsObj.cw;
        for (let k = 0; k < cw.length; k++) {
          const cwObj = cw[k];
          const wordObj = cwObj.w;
          const wpObj = cwObj.wp;
          endWordStr += wordObj.toString();
          finalWordStr += wordObj.toString();
          if (wpObj.toString() === "g") {
            endWordStr += "\r\n";
            finalWordStr += "\r\n";
          }
        }
      }
      endWordStr = endWordStr ?  endWordStr : ''
      finalWordStr = finalWordStr ? finalWordStr : ''
      replaceFinalResult(endWordStr, finalWordStr)
    }
  }
  // 中间结果
 function renderIntermediateResult(oldWordStr, renderWordStr) {
document.getElementById("oldresult").innerText = oldWordStr
  }
  // 最终结果
function  replaceFinalResult(endWordStr, finalWordStr) {
  document.getElementById("oldresult").innerText = ''
  document.getElementById("result").innerText = document.getElementById("result").innerText+ endWordStr
  }




  function connectWebSocket() {
    const websocketUrl = getWebSocketUrl();
    if ("WebSocket" in window) {
      iatWS = new WebSocket(websocketUrl);
    } else if ("MozWebSocket" in window) {
      iatWS = new MozWebSocket(websocketUrl);
    } else {
      alert("浏览器不支持WebSocket");
      return;
    }
    changeBtnStatus("CONNECTING");
    iatWS.onopen = (e) => {
      let bgMsg = {
        action: 'begin',
        id: '123',
        param: 'pk_on=1'
      }
    iatWS.send(JSON.stringify(bgMsg))  
      console.log(e, "websocket opend")
      // 开始录音
      recorder.start({
        sampleRate: 16000,
        frameSize: 1280,
      });
    };
    iatWS.onmessage = (e) => {
      renderResult(e.data);
    };
    iatWS.onerror = (e) => {
      console.error(e);
      recorder.stop();
      changeBtnStatus("CLOSED");
    };
    iatWS.onclose = (e) => {
      recorder.stop();
      changeBtnStatus("CLOSED");
    };
  }

  recorder.onFrameRecorded = ({ isLastFrame, frameBuffer }) => {
    if (iatWS.readyState === iatWS.OPEN) {
      // const mergedArray = new Uint8Array(frameBuffer);
      // // const mergedArray = new Int8Array(frameBuffer);
      // console.log(mergedArray,"mergedArraymergedArraymergedArraymergedArray")
   
      const chunkSize = 1280;
      if (!frameBuffer) {
        return
      }
      const numberOfChunks = Math.ceil(frameBuffer.byteLength / chunkSize);
      let chunks = [];
      for (let i = 0; i < numberOfChunks; i++) {
        const start = i * chunkSize;
        const end = start + chunkSize;
        chunks.push(frameBuffer.slice(start, end));
      }
      
      socketSend(chunks)

      // iatWS.send(mergedArray)
      if (isLastFrame) {
        // iatWS.send('{"end": true}');
        const edMsg = {
            action: 'end',
            id: '123',
            param: ''
        }
        iatWS.send(JSON.stringify(edMsg))  
        changeBtnStatus("CLOSING");
      }
    }
  };
  recorder.onStop = () => {
    clearInterval(countdownInterval);
  };
function socketSend(newchunks){
    let chunks = newchunks
    let index = 0;
    timer = setInterval(() => {
      var init8arr = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0]);
      if (chunks[index]) {
        var dataView = new DataView(chunks[index]);
        var uint8Array = new Uint8Array(dataView.byteLength);
        for (var i = 0; i < dataView.byteLength; i++) {
          uint8Array[i] = dataView.getUint8(i);
        }
        // 创建新的 Uint8Array，长度为两个原数组之和
        const mergedArray = new Uint8Array(init8arr.length + uint8Array.length);
        // 将第一个数组复制到新数组中
        mergedArray.set(init8arr);
        // 将第二个数组追加到新数组后面
        mergedArray.set(uint8Array, init8arr.length);
        iatWS.send(mergedArray)
        index++; // 索引自增
        if (index >= chunks.length - 1) {
          clearInterval(timer); // 如果索引大于等于数组长度，清除定时器
        }
      }
    }, 40);
}
  btnControl.onclick = function () {
    if (btnStatus === "UNDEFINED" || btnStatus === "CLOSED") {
      connectWebSocket();
    } else if (btnStatus === "CONNECTING" || btnStatus === "OPEN") {
      // 结束录音
      recorder.stop();
    }
  };
})();
